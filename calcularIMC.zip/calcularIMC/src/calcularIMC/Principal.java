package calcularIMC;

public class Principal {

	public static void main(String[] args) {
		//Objetos
		Paciente p1 = new Paciente(1.75, 82.00);
		Paciente p2 = new Paciente(1.82, 102.00);
		Paciente p3 = new Paciente(1.50, 60.00);

		p1.calcularIMC();
		p1.diagnostico();
		p1.imprimir();
		
		p2.calcularIMC();
		p2.diagnostico();
		p2.imprimir();
		
		p3.calcularIMC();
		p3.diagnostico();
		p3.imprimir();
		}
}
