package calcularIMC;

public class Paciente {
	
	Double altura;
	Double peso;
	Double IMC;
	String diagnostico;
	
	//Construtor
	public Paciente(Double altura, Double peso) {
		this.altura = altura;
		this.peso = peso;
	}
	
	//Método IMC
	public Double calcularIMC() {
		IMC = peso / (altura * altura);
		return IMC;
	} //end Paciente
	
	//Método diagnostico
	public void diagnostico() {
		if (IMC < 16) {
			diagnostico = "Baixo peso muito grave";
		}
		else if (IMC >= 16 && IMC <= 16.99) {
			diagnostico = "Baixo peso grave";
		}
		else if (IMC >= 17 && IMC <= 18.49) {
			diagnostico = "Baixo peso";
		}
		else if (IMC >= 18.50 && IMC <= 24.99) {
			diagnostico = "peso normal";
		}
		else if (IMC >= 25 && IMC <= 29.99) {
			diagnostico = "Sobrepeso";
		}
		else if (IMC >= 30 && IMC <= 34.99) {
			diagnostico = "Obesidade grau I";
		}
		else if (IMC >= 35 && IMC <= 39.99) {
			diagnostico = "Obesidade grau II";
		}
		else {
			diagnostico = "Obesidade grau III";
		}
	} //end diagnostico
	
	//Imprime as informações no console
	void imprimir( ) {
		System.out.println("Seu IMC é " + IMC);
		System.out.println("Portanto seu diagnóstico é: " + diagnostico);
		System.out.println(" ");
	} //end imprimir
} //end class

