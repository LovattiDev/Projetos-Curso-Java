package formasDeTratamento;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Teste {

	@Test
	void testNomeInformal() {
		Autoridade autoridade1 = new Autoridade("Pedro", "Cabral", new Informal());
        assertEquals(autoridade1.getTratamento(), "Pedro");
	}
	
	@Test
	void testNomeRespeitosoSr() {
		Autoridade autoridade1 = new Autoridade("Pedro", "Cabral", new Respeitoso("Sr."));
        assertEquals(autoridade1.getTratamento(), "Sr. Cabral");
	}
	
	@Test
	void testNomeRespeitosoSra() {
		Autoridade autoridade1 = new Autoridade("Maria", "Clara", new Respeitoso("Sra."));
        assertEquals(autoridade1.getTratamento(), "Sra. Clara");
	}
	
	@Test
	void testNomeComTitulo() {
		Autoridade autoridade1 = new Autoridade("Pedro", "Cabral", new ComTitulo("Senhor Supremo do Universo"));
        assertEquals(autoridade1.getTratamento(), "Senhor Supremo do Universo Pedro Cabral");
	}
}
