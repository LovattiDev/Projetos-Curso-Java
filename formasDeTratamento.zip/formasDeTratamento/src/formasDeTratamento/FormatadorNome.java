package formasDeTratamento;

public interface FormatadorNome {
	String formatarNome(String nome, String sobrenome);
}
