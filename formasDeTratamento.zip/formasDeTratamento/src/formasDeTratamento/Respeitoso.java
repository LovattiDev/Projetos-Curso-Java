package formasDeTratamento;

public class Respeitoso implements FormatadorNome{
	
	private String pronome;
	
	public Respeitoso(String pronome) {
		this.pronome = pronome;
	}
	
	@Override
	public String formatarNome(String nome, String sobrenome) {
		return pronome + " " + sobrenome;
	}
}