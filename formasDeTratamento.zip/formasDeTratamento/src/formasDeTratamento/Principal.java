package formasDeTratamento;

public class Principal {

	public static void main(String[] args) {
		Autoridade autoridade1 = new Autoridade("Pedro", "Cabral", new Informal());
        Autoridade autoridade2 = new Autoridade("Pedro", "Cabral", new Respeitoso("Sr."));
        Autoridade autoridade3 = new Autoridade("Pedro", "Cabral", new ComTitulo("Magnífico"));

        System.out.println(autoridade1.getTratamento());  // Saída: Pedro
        System.out.println(autoridade2.getTratamento());  // Saída: Sr. Cabral
        System.out.println(autoridade3.getTratamento());  // Saída: Magnífico Pedro Cabral
	}

}
