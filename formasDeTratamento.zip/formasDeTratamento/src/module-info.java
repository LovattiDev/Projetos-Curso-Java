/**
 * 
 */
/**
 * 
 */
module formasDeTratamento {
	requires org.junit.jupiter.api;
}