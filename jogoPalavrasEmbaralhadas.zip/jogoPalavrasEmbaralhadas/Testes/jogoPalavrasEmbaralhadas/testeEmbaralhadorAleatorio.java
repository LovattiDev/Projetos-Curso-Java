package jogoPalavrasEmbaralhadas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testeEmbaralhadorAleatorio {

	@Test
	void testEmbaralhadorAleatorioCorreto() {
		EmbaralhadorAleatorio embaralhar = new EmbaralhadorAleatorio();
		String stringEmbaralhada = embaralhar.embaralhar("cachorro");
		
		assertNotEquals("cachorro", stringEmbaralhada);
	}
}
