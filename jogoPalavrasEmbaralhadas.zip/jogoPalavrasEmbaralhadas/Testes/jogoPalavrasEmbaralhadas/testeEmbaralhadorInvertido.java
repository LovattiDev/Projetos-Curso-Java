package jogoPalavrasEmbaralhadas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testeEmbaralhadorInvertido {

	@Test
	void testStringInvertidaCorreto() {
		EmbaralhadorInvertido embaralhar = new EmbaralhadorInvertido();
		String palavraEmbaralhada = embaralhar.embaralhar("cachorro");
		
		assertEquals("orrohcac", palavraEmbaralhada);
	}
	
	@Test
	void testStringInvertidaNaoCorreto() {
		EmbaralhadorInvertido embaralhar = new EmbaralhadorInvertido();
		String palavraEmbaralhada = embaralhar.embaralhar("cachorro");
		
		assertNotEquals("cachorro", palavraEmbaralhada);
	}
	

}
