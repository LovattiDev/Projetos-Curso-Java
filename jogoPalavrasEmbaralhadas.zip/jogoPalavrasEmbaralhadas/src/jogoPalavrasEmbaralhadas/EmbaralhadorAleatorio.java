package jogoPalavrasEmbaralhadas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmbaralhadorAleatorio implements Embaralhador{

    public String embaralhar(String palavra) {
        List<Character> letras = new ArrayList<>();
        for (char c : palavra.toCharArray()) {
            letras.add(c);
        }
        Collections.shuffle(letras);
        StringBuilder resultado = new StringBuilder();
        for (char c : letras) {
            resultado.append(c);
        }
        return resultado.toString();
    }
}