package jogoPalavrasEmbaralhadas;

import java.util.Scanner;

public class FabricaMecanicaDoJogo {
    public static MecanicaDoJogo obterMecanicaDoJogo(Scanner scanner) {
        return new MecanicaSimples(scanner);
    }
}
