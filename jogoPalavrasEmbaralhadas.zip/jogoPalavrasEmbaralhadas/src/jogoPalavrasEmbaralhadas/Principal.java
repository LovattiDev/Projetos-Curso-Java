package jogoPalavrasEmbaralhadas;

import java.util.Scanner;

public class Principal {
    private static final int NUM_RODADAS = 5;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MecanicaDoJogo mecanica = FabricaMecanicaDoJogo.obterMecanicaDoJogo(scanner);
        BancoDePalavras bancoDePalavras = new BancoDePalavras();

        for (int i = 0; i < NUM_RODADAS; i++) {
            String palavra = bancoDePalavras.obterPalavraAleatoria();
            while (!mecanica.jogoAcabou()) {
                if (mecanica.tentativa(palavra)) {
                    break;
                }
            }
        }
        System.out.println("Pontuação final: " + mecanica.pontuacaoFinal());
        scanner.close();
    }
}
