package jogoPalavrasEmbaralhadas;

//Implementações de embaralhadores
public class EmbaralhadorInvertido implements Embaralhador{
   
	public String embaralhar(String palavra) {
        return new StringBuilder(palavra).reverse().toString();
    }
}
