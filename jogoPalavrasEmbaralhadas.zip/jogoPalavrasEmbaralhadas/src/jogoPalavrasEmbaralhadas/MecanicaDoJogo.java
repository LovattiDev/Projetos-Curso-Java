package jogoPalavrasEmbaralhadas;

public interface MecanicaDoJogo {
	
    boolean jogoAcabou();
    boolean tentativa(String palavra);
    int pontuacaoFinal();
}
