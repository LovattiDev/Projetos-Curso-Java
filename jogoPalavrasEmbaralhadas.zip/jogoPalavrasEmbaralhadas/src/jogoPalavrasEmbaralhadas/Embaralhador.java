package jogoPalavrasEmbaralhadas;

public interface Embaralhador {
	String embaralhar(String palavra);
}
