package jogoPalavrasEmbaralhadas;

import java.util.Random;

public class BancoDePalavras {
	
    private static final String[] PALAVRAS = {"gato", "cachorro", "elefante", "papagaio",
    		"macaco", "leao", "tigre", "cobra", "jacare", "girafa", "rato", "lobo", "sapo",
    		"camelo", "pinguim", "peixe", "pombo", "zebra", "vaca", "baleia"};
    
    private static final int NUM_PALAVRAS = PALAVRAS.length;
    private static final Random random = new Random();

    // Método para obter uma palavra aleatória do array fixo
    public String obterPalavraAleatoria() {
        int indice = random.nextInt(NUM_PALAVRAS);
        return PALAVRAS[indice];
    }
}    
        
