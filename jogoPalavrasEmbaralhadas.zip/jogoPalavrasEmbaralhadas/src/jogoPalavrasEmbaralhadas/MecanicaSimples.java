package jogoPalavrasEmbaralhadas;

import java.util.Scanner;

public class MecanicaSimples implements MecanicaDoJogo {
    private int pontos;
    private int tentativas;
    private final int MAX_TENTATIVAS = 3;
    private final Scanner scanner;

    public MecanicaSimples(Scanner scanner) {
        this.scanner = scanner;
        pontos = 0;
        tentativas = 0;
    }

    public boolean jogoAcabou() {
        return tentativas >= MAX_TENTATIVAS;
    }

    public boolean tentativa(String palavra) {
        Embaralhador embaralhador = FabricaEmbaralhadores.obterEmbaralhadorAleatorio();
        System.out.println("Tentativa: " + (tentativas + 1));
        System.out.println("Palavra embaralhada: " + embaralhador.embaralhar(palavra));
        System.out.print("Sua resposta: ");
        String resposta = scanner.nextLine();
        if (resposta.equalsIgnoreCase(palavra)) {
            pontos++;
            System.out.println("Correto!");
            return true;
        } else {
            System.out.println("Incorreto! Tente novamente.");
            tentativas++;
            return false;
        }
    }

    public int pontuacaoFinal() {
        return pontos;
    }
}
