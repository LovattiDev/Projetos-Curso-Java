package jogoPalavrasEmbaralhadas;

import java.util.Random;

public class FabricaEmbaralhadores {
    private static final Random random = new Random();

    public static Embaralhador obterEmbaralhadorAleatorio() {
        if (random.nextBoolean()) {
            return new EmbaralhadorInvertido();
        } else {
            return new EmbaralhadorAleatorio();
        }
    }
}
