package diferentesTiposDeProdutos;

import static org.junit.Assert.*;

import org.junit.Test;

public class testeProduto {


    private Produto produto;

    @org.junit.Before
    public void setUp() {
        produto = new Produto("ProdutoTest", 1, 10.0);
    }

    @Test
    public void testGetNome() {
        assertEquals("ProdutoTest", produto.getNome());
    }

    @Test
    public void testGetCodigo() {
        assertEquals(1, produto.getCodigo());
    }

    @Test
    public void testGetPreco() {
        assertEquals(10.0, produto.getPreco(), 0.001);
    }
}
