package diferentesTiposDeProdutos;

import static org.junit.Assert.*;

import org.junit.Test;

public class testeProdutoComTamanho {

    private ProdutoComTamanho produtoComTamanho;

    @org.junit.Before
    public void setUp() {
        produtoComTamanho = new ProdutoComTamanho("ProdutoComTamanhoTest", 1, 20.0, "XL");
    }

    @Test
    public void testGetTamanho() {
        assertEquals("XL", produtoComTamanho.getTamanho());
    }
}
