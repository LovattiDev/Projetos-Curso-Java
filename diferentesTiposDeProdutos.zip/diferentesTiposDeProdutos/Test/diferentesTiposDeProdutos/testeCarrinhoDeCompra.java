package diferentesTiposDeProdutos;

import static org.junit.Assert.*;

import org.junit.Test;

public class testeCarrinhoDeCompra {

    private CarrinhoDeCompras carrinho;

    @org.junit.Before
    public void setUp() {
        carrinho = new CarrinhoDeCompras();
    }

    @Test
    public void testAdicionaProduto() {
        Produto produto1 = new Produto("Produto1", 1, 10.0);
        carrinho.adicionaProduto(produto1, 3);

        assertEquals(3, carrinho.getQuantidade(produto1));
    }

    @Test
    public void testAdicionaProdutoExistente() {
        Produto produto1 = new Produto("Produto1", 1, 10.0);
        carrinho.adicionaProduto(produto1, 3);
        carrinho.adicionaProduto(produto1, 2);

        assertEquals(5, carrinho.getQuantidade(produto1));
    }

    @Test
    public void testRemoveProduto() {
        Produto produto1 = new Produto("Produto1", 1, 10.0);
        carrinho.adicionaProduto(produto1, 3);
        carrinho.removeProduto(produto1, 2);

        assertEquals(1, carrinho.getQuantidade(produto1));
    }

    @Test
    public void testRemoveProdutoInexistente() {
        Produto produto1 = new Produto("Produto1", 1, 10.0);
        carrinho.removeProduto(produto1, 2);

        assertEquals(0, carrinho.getQuantidade(produto1));
    }

    @Test
    public void testCalcularValorTotal() {
        Produto produto1 = new Produto("Produto1", 1, 10.0);
        Produto produto2 = new Produto("Produto2", 2, 15.0);

        carrinho.adicionaProduto(produto1, 3);
        carrinho.adicionaProduto(produto2, 2);

        assertEquals(3 * 10.0 + 2 * 15.0, carrinho.calcularValorTotal(), 0.001);
    }

}
