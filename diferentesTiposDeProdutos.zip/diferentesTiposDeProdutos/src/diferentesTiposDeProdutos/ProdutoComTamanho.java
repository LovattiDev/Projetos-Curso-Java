package diferentesTiposDeProdutos;

public class ProdutoComTamanho extends Produto{
	
	private String tamanho;

	public ProdutoComTamanho(String nome, int codigo, double preco, String tamanho) {
		super(nome, codigo, preco);
        this.tamanho = tamanho;
	}
	
	public String getTamanho() {
		
		return tamanho;
	}

}
