package diferentesTiposDeProdutos;

public class Principal {

	public static void main(String[] args) {
	
		Produto produto1 = new Produto("Produto A", 1, 10.0);
        Produto produto2 = new ProdutoComTamanho("Produto B", 2, 15.0, "M");

        CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
        carrinho.adicionaProduto(produto1, 3);
        carrinho.adicionaProduto(produto2, 2);

        System.out.println("Valor total no carrinho: " + carrinho.calcularValorTotal());
	}

}
