package diferentesTiposDeProdutos;

import java.util.HashMap;

public class CarrinhoDeCompras {
    
	private HashMap<Produto, Integer> carrinho = new HashMap<>();

    public void adicionaProduto(Produto produto, int quantidade) {
        carrinho.put(produto, carrinho.getOrDefault(produto, 0) + quantidade);
    }

    public void removeProduto(Produto produto, int quantidade) {
        if (carrinho.containsKey(produto)) {
            int quantidadeAtual = carrinho.get(produto);
            if (quantidadeAtual <= quantidade) {
                carrinho.remove(produto);
            } else {
                carrinho.put(produto, quantidadeAtual - quantidade);
            }
        }
    }

    public double calcularValorTotal() {
        double valorTotal = 0.0;
        for (Produto produto : carrinho.keySet()) {
            valorTotal += produto.preco * carrinho.get(produto);
        }
        return valorTotal;
    }
    
    public int getQuantidade(Produto produto) {
        return carrinho.getOrDefault(produto, 0);
    }
}
