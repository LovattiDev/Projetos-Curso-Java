package pizzaria;

import java.util.HashMap;

public class Pizza {
	//Cria o HashMap
	private static HashMap<String, Integer> ingredientes = new HashMap<>();
    private int quantidadeIngredientes;

    //Método adicionaIngrediente
    public void adicionaIngrediente(String ingrediente) {
        contabilizaIngrediente(ingrediente);
        quantidadeIngredientes++;
    }
    
    //Adiciona os ingredientes no HashMap
    private static void contabilizaIngrediente(String ingrediente) {
        ingredientes.put(ingrediente, ingredientes.getOrDefault(ingrediente, 0) + 1);
    }
    
    //Método getPreco
    public int getPreco() {
        if (quantidadeIngredientes <= 2) {
            return 15;
        } else if (quantidadeIngredientes <= 5) {
            return 20;
        } else {
            return 23;
        }
    }
    
    public static boolean zerar() {
    	ingredientes.clear();
    	return ingredientes.isEmpty();
    }

    public static HashMap<String, Integer> getIngredientes() {
        return new HashMap<>(ingredientes);
    }
    
    public int getQuantidadeIngredientes() {
    	return quantidadeIngredientes;
    }
}
