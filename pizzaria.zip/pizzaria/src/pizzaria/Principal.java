package pizzaria;

public class Principal {

	public static void main(String[] args) {
		
		//Cria o objeto pizza1
		Pizza pizza1 = new Pizza();
		//Adiciona os ingredientes
        pizza1.adicionaIngrediente("Queijo");
        pizza1.adicionaIngrediente("Tomate");

		//Cria o objeto pizza1
        Pizza pizza2 = new Pizza();
		//Adiciona os ingredientes
        pizza2.adicionaIngrediente("Queijo");
        pizza2.adicionaIngrediente("Presunto");
        pizza2.adicionaIngrediente("Cogumelos");
        
		//Cria o objeto pizza1
        Pizza pizza3 = new Pizza();
		//Adiciona os ingredientes
        pizza3.adicionaIngrediente("Queijo");
        pizza3.adicionaIngrediente("Calabresa");
        pizza3.adicionaIngrediente("Cebola");
        pizza3.adicionaIngrediente("Tomate");
        pizza3.adicionaIngrediente("Azeitona");
        pizza3.adicionaIngrediente("Cogumelos");

		//Cria o objeto pizza1
        CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
		//Adiciona as pizzas
        carrinho.adicionarPizza(pizza1);
        carrinho.adicionarPizza(pizza2);
        carrinho.adicionarPizza(pizza3);

        System.out.println("Total do Carrinho de Compras: R$" + carrinho.getTotal());

        System.out.println("Quantidade de ingredientes utilizados:");
        for (String ingrediente : Pizza.getIngredientes().keySet()) {
            System.out.println(ingrediente + ": " + Pizza.getIngredientes().get(ingrediente));
        }
	}
}
