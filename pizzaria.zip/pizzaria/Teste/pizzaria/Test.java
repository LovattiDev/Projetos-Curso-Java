package pizzaria;

import static org.junit.Assert.*;

public class Test {

	//Teste zerar HashMap
	@org.junit.Before
	public void testeZerar() {
		Pizza pizza1 = new Pizza();
		//Adiciona os ingredientes
        pizza1.adicionaIngrediente("Queijo");
        pizza1.adicionaIngrediente("Tomate");
        
        assertEquals(true, Pizza.zerar());
	}
	
	//Teste quantidade de ingredientes
	@org.junit.Test
	public void testIngredientesPizza1() {
		//Cria o objeto pizza1
		Pizza pizza1 = new Pizza();
		//Adiciona os ingredientes
        pizza1.adicionaIngrediente("Queijo");
        pizza1.adicionaIngrediente("Tomate");
        
        assertEquals(2, pizza1.getQuantidadeIngredientes());
        }
	
	//Teste preço pizza
	@org.junit.Test
	public void testPrecoPizza1() {
		Pizza pizza1 = new Pizza();
		//Adiciona os ingredientes
        pizza1.adicionaIngrediente("Queijo");
        pizza1.adicionaIngrediente("Tomate");
        
        assertEquals(15, pizza1.getPreco());
	}
	
	//Teste quantidade de ingredientes
	@org.junit.Test
	public void testIngredientesPizza2() {
        Pizza pizza2 = new Pizza();
		//Adiciona os ingredientes
        pizza2.adicionaIngrediente("Queijo");
        pizza2.adicionaIngrediente("Presunto");
        pizza2.adicionaIngrediente("Cogumelos");
        
        assertEquals(3, pizza2.getQuantidadeIngredientes());
	}
	
	//Teste preço pizza
	@org.junit.Test
	public void testPrecoPizza2() {
		Pizza pizza2 = new Pizza();
		//Adiciona os ingredientes
        pizza2.adicionaIngrediente("Queijo");
        pizza2.adicionaIngrediente("Presunto");
        pizza2.adicionaIngrediente("Cogumelos");
        
        assertEquals(20, pizza2.getPreco());
	}
	
	//Teste quantidade de ingredientes
	@org.junit.Test
	public void testIngredientesPizza3() {
        Pizza pizza3 = new Pizza();
		//Adiciona os ingredientes
        pizza3.adicionaIngrediente("Queijo");
        pizza3.adicionaIngrediente("Calabresa");
        pizza3.adicionaIngrediente("Cebola");
        pizza3.adicionaIngrediente("Tomate");
        pizza3.adicionaIngrediente("Azeitona");
        pizza3.adicionaIngrediente("Cogumelos");
        
        assertEquals(6, pizza3.getQuantidadeIngredientes());
	}
	
	//Teste preço pizza
	@org.junit.Test
	public void testPrecoPizza3() {
		Pizza pizza3 = new Pizza();
		//Adiciona os ingredientes
        pizza3.adicionaIngrediente("Queijo");
        pizza3.adicionaIngrediente("Calabresa");
        pizza3.adicionaIngrediente("Cebola");
        pizza3.adicionaIngrediente("Tomate");
        pizza3.adicionaIngrediente("Azeitona");
        pizza3.adicionaIngrediente("Cogumelos");
        
        assertEquals(23, pizza3.getPreco());
	}

	//Teste preço total
	@org.junit.Test
	public void testPrecoTotal() {
		Pizza pizza1 = new Pizza();
		Pizza pizza2 = new Pizza();
		CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
		//Adiciona os ingredientes
        pizza1.adicionaIngrediente("Queijo");
        pizza1.adicionaIngrediente("Tomate");
		//Adiciona os ingredientes
        pizza2.adicionaIngrediente("Queijo");
        pizza2.adicionaIngrediente("Presunto");
        pizza2.adicionaIngrediente("Cogumelos");
       
        carrinho.adicionarPizza(pizza1);
        carrinho.adicionarPizza(pizza2);
        
        assertEquals(35, carrinho.getTotal());
	}
	
	//Teste pizza sem ingredientes
	@org.junit.Test
	public void testPizzaSemIngredientes() {
		Pizza pizza1 = new Pizza();
		Pizza pizza2 = new Pizza();
		CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
		//Adiciona os ingredientes
        pizza1.adicionaIngrediente("Queijo");
        pizza1.adicionaIngrediente("Tomate");
       
        carrinho.adicionarPizza(pizza1);
        carrinho.adicionarPizza(pizza2);
        
        assertEquals(15, carrinho.getTotal());
	}
}
